=== EZPin ===
Contributors: iamrook
Tags: pinterest, images, social sharing, save button
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Pinterest image Save buttons that link Pins back to the original WordPress page.

== Description ==
EZPin provides desktop hover buttons, mobile Save controls, per-page and per-image Pinterest metadata, exclusions, and hidden Pinterest images. It keeps the image URL separate from the canonical destination and preserves accessibility alt text. No Pinterest API credentials or remote JavaScript are needed.

Configure Settings > EZPin, the EZPin box in the page editor, and the Pinterest fields in the Media Library. Image-level data-pin-title, data-pin-description, data-pin-media and data-pin-url attributes take priority.

== External services ==
When a visitor clicks Save, Pinterest receives the selected image URL, destination URL, and optional title and description through https://www.pinterest.com/pin/create/button/. No Pinterest requests are made by this plugin before that click. The visitor completes authentication and board selection on Pinterest. Pinterest controls the final title and save interface.
Save opens a centered 760 by 640 popup window, with the regular link as a fallback when popups are blocked. Mobile browsers may open a tab. Pinterest does not allow its save screen to be embedded in another site's modal.
Pinterest terms: https://policy.pinterest.com/en/terms-of-service
Pinterest privacy: https://policy.pinterest.com/en/privacy-policy

WordPress update checks contact GitHub to retrieve release metadata from https://github.com/iamrook/ezpin-releases/releases/latest/download/ezpin-update.json. Downloads come from versioned assets in that repository. GitHub receives the server IP and updater version; EZPin does not send site content, visitor data, license keys, or the site URL in its metadata request. Results are cached for six hours (failed checks for fifteen minutes). GitHub may redirect downloads to its asset hosting domains. Release ZIPs are checked against the published SHA-256 before installation. No GitHub account or access token is required.
GitHub terms: https://docs.github.com/en/site-policy/github-terms/github-terms-of-service
GitHub privacy: https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement

== Installation ==
1. Download the ezpin-VERSION.zip asset from https://github.com/iamrook/ezpin-releases/releases/latest and upload it using Plugins > Add New > Upload Plugin. Use the release asset, not GitHub's source-code ZIP.
2. Activate EZPin in Plugins.
3. Configure Settings > EZPin.

== Frequently Asked Questions ==
= Does the Pin link to the image file? =
No. By default it links to the current page's canonical URL; the media parameter is the selected image. An explicit image Pinterest destination can override this.

= Is a Pinterest API key required? =
No. Visitors use Pinterest's public Save interface and their own account.

= Does this change image alt text? =
No. Pinterest fields are separate from alt text.

= Can I pin a hidden vertical image? =
Yes. Choose a hidden image globally or for a page. It gets a dedicated Save link and can optionally replace normal image selections.

= What happens when I deactivate or delete EZPin? =
Buttons stop loading. Settings and metadata remain to preserve editorial work.

= How do updates work? =
While EZPin is active, new stable GitHub releases appear in the normal WordPress update screen. Use Dashboard > Updates > Check again to refresh immediately. You can enable automatic updates in Plugins; EZPin never enables them for you. Updates preserve settings and image/page metadata. An inactive copy cannot run its GitHub updater; reactivate it or upload the latest ZIP manually.

= How do I upgrade from 1.0.2 or earlier? =
Upload the new release ZIP once and choose to replace the installed plugin. Those older versions have no GitHub updater. Version 1.1.0 and later can discover subsequent releases automatically.

== Changelog ==
= 1.1.0 =
Receive stable GitHub releases through WordPress's normal update screen, with optional administrator-controlled automatic updates, release details, cached checks, and SHA-256 package verification. Add reproducible release packaging and a tested GitHub release workflow. Existing settings and Pinterest behavior are preserved.

= 1.0.2 =
Navigate popups directly to Pinterest for compatibility with browsers that intercept new windows.

= 1.0.1 =
Open the Pinterest Save interface in a centered compact popup with a safe native-link fallback, preserving keyboard and modified-click behavior.

= 1.0.0 =
Initial release.
