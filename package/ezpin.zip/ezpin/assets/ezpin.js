/* global EZPinConfig */
(() => {
    'use strict';
    if (!window.EZPinConfig || document.getElementById('ezpin-layer')) return;
    const config = window.EZPinConfig;
    const page = config.page || {};
    const records = new Map();
    const builtInExclusions = 'nav, aside, footer, [role="navigation"], [role="complementary"], .site-header, .site-logo, .custom-logo, .logo, .avatar, .emoji, .icon, .adsbygoogle, [data-pin-nopin], [nopin], [data-pin-no-hover], .no-pinterest, .no-pin, [hidden], [aria-hidden="true"]';
    // Validate each rule independently so one typo never disables every exclusion.
    const validSelectors = (value) => String(value || '').split(/\n/).flatMap((line) => {
        try {
            document.querySelector(line.trim());
            return line.trim() ? [line.trim()] : [];
        } catch (_) {
            return line.split(',').filter((part) => {
                try { document.querySelector(part.trim()); return !!part.trim(); } catch (_) { return false; }
            });
        }
    });
    const scopes = validSelectors(config.scope);
    const exclusions = [builtInExclusions, ...validSelectors(config.excluded)];
    const layer = document.createElement('div');
    layer.id = 'ezpin-layer';
    layer.className = 'ezpin-layer';
    layer.dataset.desktop = config.desktop;
    layer.dataset.mobile = config.mobile;
    document.body.append(layer);

    const absoluteURL = (value) => {
        if (!value || typeof value !== 'string') return '';
        try {
            const url = new URL(value, document.baseURI);
            return ['http:', 'https:'].includes(url.protocol) ? url.href : '';
        } catch (_) { return ''; }
    };
    const meta = (selector) => document.querySelector(selector)?.content?.trim() || '';
    const firstText = (...values) => values.find((value) => typeof value === 'string' && value.trim())?.trim() || '';
    const firstURL = (...values) => values.map(absoluteURL).find(Boolean) || '';
    const largestSource = (image) => {
        // WordPress and standard responsive srcsets use width or density descriptors.
        const set = image.getAttribute('srcset') || image.getAttribute('data-srcset') || '';
        return set.split(',').map((entry) => {
            const [url, descriptor = '1x'] = entry.trim().split(/\s+/);
            return { url: absoluteURL(url), size: parseFloat(descriptor) || 0 };
        }).filter((source) => source.url).sort((a, b) => b.size - a.size)[0]?.url || '';
    };
    const pinURL = (image, hiddenImage = '') => {
        const destination = firstURL(image?.getAttribute('data-pin-url'), document.querySelector('link[rel="canonical"]')?.href, window.location.href);
        const media = hiddenImage || firstURL(
            image?.getAttribute('data-pin-media'),
            page.forceImage ? page.image : '',
            image?.getAttribute('data-ezpin-full'),
            image?.getAttribute('data-full-url'),
            image?.getAttribute('data-large_image'),
            image ? largestSource(image) : '',
            image?.currentSrc,
            image?.getAttribute('src'),
            image?.getAttribute('data-src'),
            image?.getAttribute('data-lazy-src')
        );
        if (!destination || !media) return '';
        const title = firstText(image?.getAttribute('data-pin-title'), page.title, meta('meta[property="og:title"]'), document.title);
        const description = firstText(image?.getAttribute('data-pin-description'), page.description, meta('meta[name="description"]'));
        const url = new URL('https://www.pinterest.com/pin/create/button/');
        url.searchParams.set('url', destination);
        url.searchParams.set('media', media);
        url.searchParams.set('description', description.slice(0, 500));
        if (title) url.searchParams.set('title', title.slice(0, 100));
        return url.href;
    };
    const icon = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 0a12 12 0 0 0-4.37 23.18c-.1-1.03-.2-2.61.04-3.74l1.41-5.98s-.36-.72-.36-1.78c0-1.67.97-2.92 2.18-2.92 1.03 0 1.53.77 1.53 1.69 0 1.03-.66 2.57-1 4-.29 1.2.6 2.18 1.78 2.18 2.14 0 3.79-2.26 3.79-5.52 0-2.89-2.07-4.91-5.02-4.91-3.42 0-5.43 2.56-5.43 5.21 0 1.03.4 2.14.89 2.74.1.12.11.22.08.34l-.33 1.37c-.05.22-.17.27-.4.17-1.49-.7-2.42-2.87-2.42-4.62 0-3.76 2.73-7.21 7.88-7.21 4.14 0 7.36 2.95 7.36 6.9 0 4.12-2.6 7.44-6.2 7.44-1.21 0-2.35-.63-2.74-1.38l-.75 2.86c-.27 1.05-1 2.36-1.5 3.16A12 12 0 1 0 12 0Z"/></svg>';
    const makeLink = (image, hiddenImage = '') => {
        const link = document.createElement('a');
        link.className = 'ezpin-button';
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.setAttribute('aria-label', config.label || 'Save image to Pinterest (opens in a new window)');
        // This SVG is a fixed local string; metadata is never inserted as HTML.
        link.innerHTML = icon;
        const text = document.createElement('span');
        text.textContent = config.buttonText || 'Save';
        link.append(text);
        const refresh = () => { link.href = pinURL(image, hiddenImage); };
        refresh();
        for (const event of ['pointerdown', 'focus', 'click']) link.addEventListener(event, refresh);
        link.addEventListener('click', (event) => {
            // Leave modified clicks to the browser's normal new-tab/window behavior.
            if (event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
            const width = Math.min(760, window.screen.availWidth || 760);
            const height = Math.min(640, window.screen.availHeight || 640);
            const screenLeft = window.screen.availLeft || 0;
            const screenTop = window.screen.availTop || 0;
            const left = Math.max(screenLeft, Math.min(window.screenX + (window.outerWidth - width) / 2, screenLeft + (window.screen.availWidth || width) - width));
            const top = Math.max(screenTop, Math.min(window.screenY + (window.outerHeight - height) / 2, screenTop + (window.screen.availHeight || height) - height));
            let popup;
            try {
                // Open the actual URL synchronously: some embedded browsers cannot
                // navigate a separately created blank popup. Keep the handle so a
                // blocked request can fall back to the native link.
                popup = window.open(link.href, '_blank', `popup=yes,width=${width},height=${height},left=${Math.round(left)},top=${Math.round(top)},resizable=yes,scrollbars=yes`);
                if (!popup) return;
                // Remote navigation is asynchronous. Detach the opener in this same
                // click task, before the third-party document can load or run code.
                popup.opener = null;
            } catch (_) {
                try { popup?.close(); } catch (_) { /* Native link remains usable. */ }
                return;
            }
            // Suppress the native link only after a window was opened and navigated.
            event.preventDefault();
            try { popup.focus(); } catch (_) { /* Browser controls window focus. */ }
        });
        return link;
    };
    const eligible = (image) => {
        if (!image.isConnected || !image.complete || !image.naturalWidth || !image.naturalHeight) return false;
        if (!scopes.some((selector) => image.closest(selector))) return false;
        if (exclusions.some((selector) => image.closest(selector))) return false;
        // Browsers density-correct naturalWidth for srcset. Use the full attachment
        // dimensions when known, so responsive mobile images remain pinnable.
        const width = Number(image.dataset.ezpinWidth) || image.naturalWidth;
        const height = Number(image.dataset.ezpinHeight) || image.naturalHeight;
        if (width < config.minWidth || height < config.minHeight) return false;
        return !!pinURL(image);
    };
    let pending = false;
    let needsScan = true;
    const resizeObserver = window.ResizeObserver ? new ResizeObserver(() => schedule()) : null;
    const schedule = (scan = false) => {
        needsScan = needsScan || scan;
        if (pending) return;
        pending = true;
        requestAnimationFrame(() => {
            pending = false;
            if (needsScan) {
                needsScan = false;
                reconcile();
            }
            position();
        });
    };
    const reconcile = () => {
        for (const [image, link] of records) {
            if (!eligible(image)) {
                resizeObserver?.unobserve(image);
                link.remove();
                records.delete(image);
            }
        }
        // querySelectorAll deduplicates images that match multiple content containers.
        for (const image of document.querySelectorAll('img')) {
            if (records.has(image) || !eligible(image)) continue;
            const link = makeLink(image);
            layer.append(link);
            records.set(image, link);
            resizeObserver?.observe(image);
        }
        hiddenLink();
    };
    const position = () => {
        const origin = layer.getBoundingClientRect();
        for (const [image, link] of records) {
            const rect = image.getBoundingClientRect();
            const style = getComputedStyle(image);
            const visible = rect.width >= 48 && rect.height >= 48 && rect.bottom > 0 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth && style.visibility !== 'hidden' && style.display !== 'none' && style.opacity !== '0';
            link.hidden = !visible;
            if (!visible) continue;
            const width = link.offsetWidth;
            const height = link.offsetHeight;
            const inset = Math.min(12, Math.max(0, (rect.width - width) / 2));
            let x = rect.left + inset;
            let y = rect.top + inset;
            if (config.position?.endsWith('right')) x = rect.right - width - inset;
            if (config.position?.startsWith('bottom')) y = rect.bottom - height - inset;
            if (config.position === 'center') {
                x = rect.left + (rect.width - width) / 2;
                y = rect.top + (rect.height - height) / 2;
            }
            link.style.left = `${Math.round(x - origin.left)}px`;
            link.style.top = `${Math.round(y - origin.top)}px`;
        }
    };
    const hiddenLink = () => {
        const image = absoluteURL(page.image);
        if (!image || document.querySelector('.ezpin-hidden-image-save')) return;
        const container = document.querySelector('.entry-content') || document.querySelector(scopes.join(',') || 'main');
        if (!container) return;
        const wrapper = document.createElement('p');
        wrapper.className = 'ezpin-hidden-image-save';
        const link = makeLink(null, image);
        link.classList.add('ezpin-hidden-image-button');
        link.dataset.mobile = config.mobile;
        link.setAttribute('aria-label', `${config.hiddenLabel || 'Save the Pinterest image'} (opens in a new window)`);
        link.querySelector('span').textContent = config.hiddenLabel || 'Save the Pinterest image';
        wrapper.append(link);
        container.append(wrapper);
    };
    document.addEventListener('pointerover', (event) => {
        const link = records.get(event.target);
        if (link) link.classList.add('ezpin-hover');
    });
    document.addEventListener('pointerout', (event) => {
        const link = records.get(event.target);
        if (link) link.classList.remove('ezpin-hover');
    });
    document.addEventListener('load', (event) => { if (event.target.tagName === 'IMG') schedule(true); }, true);
    const ownNode = (node) => node.nodeType === 1 && (node.id === 'ezpin-layer' || node.closest?.('#ezpin-layer, .ezpin-hidden-image-save'));
    new MutationObserver((mutations) => {
        if (mutations.some((mutation) => !ownNode(mutation.target) && (mutation.type === 'attributes' || [...mutation.addedNodes, ...mutation.removedNodes].some((node) => !ownNode(node))))) schedule(true);
    }).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['src', 'srcset', 'sizes', 'data-src', 'data-srcset', 'data-lazy-src', 'data-pin-url', 'data-pin-media', 'data-pin-title', 'data-pin-description', 'data-pin-nopin', 'data-pin-no-hover', 'nopin', 'data-ezpin-full', 'data-ezpin-width', 'data-ezpin-height', 'class', 'style', 'hidden', 'aria-hidden'] });
    addEventListener('resize', () => schedule(true), { passive: true });
    addEventListener('scroll', () => schedule(), { passive: true, capture: true });
    addEventListener('pageshow', () => schedule(true));
    document.fonts?.ready.then(() => schedule());
    resizeObserver?.observe(document.body);
    schedule(true);
})();
