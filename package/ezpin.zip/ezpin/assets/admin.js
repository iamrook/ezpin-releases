/* global wp */
(() => {
    'use strict';
    document.addEventListener('click', (event) => {
        const button = event.target.closest('.ezpin-choose-image, .ezpin-clear-image');
        if (!button) return;
        event.preventDefault();
        const field = document.getElementById(button.dataset.target);
        if (!field) return;
        if (button.classList.contains('ezpin-clear-image')) {
            field.value = '';
            field.dispatchEvent(new Event('change', { bubbles: true }));
            return;
        }
        const frame = wp.media({ title: 'Choose a Pinterest image', library: { type: 'image' }, multiple: false, button: { text: 'Use this image' } });
        frame.on('select', () => {
            field.value = frame.state().get('selection').first().toJSON().url;
            field.dispatchEvent(new Event('change', { bubbles: true }));
        });
        frame.open();
    });
})();
