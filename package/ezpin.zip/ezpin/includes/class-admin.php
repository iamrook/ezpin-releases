<?php
namespace EZPin;

defined( 'ABSPATH' ) || exit;

final class Admin {
    public static function boot() {
        add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
        add_action( 'admin_init', array( __CLASS__, 'register' ) );
        add_action( 'add_meta_boxes', array( __CLASS__, 'meta_boxes' ) );
        add_action( 'save_post', array( __CLASS__, 'save_post' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
        add_filter( 'attachment_fields_to_edit', array( __CLASS__, 'attachment_fields' ), 10, 2 );
        add_filter( 'attachment_fields_to_save', array( __CLASS__, 'save_attachment' ), 10, 2 );
    }

    public static function menu() {
        add_options_page( 'EZPin', 'EZPin', 'manage_options', 'ezpin', array( __CLASS__, 'settings_page' ) );
    }

    public static function register() {
        register_setting( 'ezpin', 'ezpin_settings', array( 'type' => 'array', 'sanitize_callback' => array( __CLASS__, 'sanitize' ) ) );
    }

    public static function text( $value, $multiline = false ) {
        return is_string( $value ) ? ( $multiline ? sanitize_textarea_field( $value ) : sanitize_text_field( $value ) ) : '';
    }

    public static function sanitize( $input ) {
        $input = is_array( $input ) ? $input : array();
        $out = Plugin::defaults();
        foreach ( array( 'enabled', 'force_image' ) as $key ) {
            $out[ $key ] = ! empty( $input[ $key ] ) && is_scalar( $input[ $key ] );
        }
        $enums = array(
            'button_text' => array( 'Save', 'Pin It', 'Save to Pinterest' ),
            'position' => array( 'top-left', 'top-right', 'bottom-left', 'bottom-right', 'center' ),
            'desktop' => array( 'hover', 'always' ),
            'mobile' => array( 'visible', 'hidden' ),
        );
        foreach ( $enums as $key => $values ) {
            if ( isset( $input[ $key ] ) && in_array( $input[ $key ], $values, true ) ) {
                $out[ $key ] = $input[ $key ];
            }
        }
        foreach ( array( 'min_width', 'min_height' ) as $key ) {
            if ( isset( $input[ $key ] ) && is_numeric( $input[ $key ] ) ) {
                $out[ $key ] = max( 1, min( 10000, (int) $input[ $key ] ) );
            }
        }
        foreach ( array( 'title', 'description', 'scope', 'excluded' ) as $key ) {
            $out[ $key ] = self::text( $input[ $key ] ?? '', 'description' === $key || 'excluded' === $key );
        }
        $out['scope'] = $out['scope'] ?: Plugin::defaults()['scope'];
        $out['image'] = Plugin::http_url( $input['image'] ?? '' );
        $types = isset( $input['post_types'] ) && is_array( $input['post_types'] ) ? $input['post_types'] : array();
        $out['post_types'] = array_values( array_intersect( array_filter( $types, 'is_string' ), array_keys( self::post_types() ) ) );
        return $out;
    }

    public static function post_types() {
        $types = get_post_types( array( 'public' => true ), 'objects' );
        unset( $types['attachment'] );
        return $types;
    }

    public static function select( $name, $value, $options ) {
        echo '<select id="' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '">';
        foreach ( $options as $key => $label ) {
            echo '<option value="' . esc_attr( $key ) . '" ' . selected( $value, $key, false ) . '>' . esc_html( $label ) . '</option>';
        }
        echo '</select>';
    }

    public static function image_field( $name, $value ) {
        echo '<input class="large-text" type="url" id="' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" placeholder="https://example.com/pinterest-image.jpg">';
        echo '<button type="button" class="button ezpin-choose-image" data-target="' . esc_attr( $name ) . '">' . esc_html__( 'Choose image', 'ezpin' ) . '</button> ';
        echo '<button type="button" class="button ezpin-clear-image" data-target="' . esc_attr( $name ) . '">' . esc_html__( 'Clear', 'ezpin' ) . '</button>';
    }

    public static function settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $s = Plugin::settings();
        ?>
        <div class="wrap" style="max-width:960px">
            <h1>EZPin</h1>
            <p><?php esc_html_e( 'Let readers save your images to Pinterest and bring visitors back to the original page.', 'ezpin' ); ?></p>
            <?php settings_errors(); ?>
            <form method="post" action="options.php">
                <?php settings_fields( 'ezpin' ); ?>
                <h2><?php esc_html_e( 'Save buttons', 'ezpin' ); ?></h2>
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><?php esc_html_e( 'Enable EZPin', 'ezpin' ); ?></th><td><label><input type="checkbox" name="ezpin_settings[enabled]" value="1" <?php checked( $s['enabled'] ); ?>> <?php esc_html_e( 'Show Pinterest image buttons', 'ezpin' ); ?></label></td></tr>
                    <?php
                    $selects = array(
                        'button_text' => array( __( 'Button text', 'ezpin' ), array( 'Save' => 'Save', 'Pin It' => 'Pin It', 'Save to Pinterest' => 'Save to Pinterest' ) ),
                        'position' => array( __( 'Button position', 'ezpin' ), array( 'top-left' => 'Top left', 'top-right' => 'Top right', 'bottom-left' => 'Bottom left', 'bottom-right' => 'Bottom right', 'center' => 'Center' ) ),
                        'desktop' => array( __( 'Desktop behavior', 'ezpin' ), array( 'hover' => 'Show on image hover or keyboard focus', 'always' => 'Always visible' ) ),
                        'mobile' => array( __( 'Mobile behavior', 'ezpin' ), array( 'visible' => 'Visible', 'hidden' => 'Hidden' ) ),
                    );
                    foreach ( $selects as $key => $field ) {
                        echo '<tr><th scope="row"><label for="ezpin_settings[' . esc_attr( $key ) . ']">' . esc_html( $field[0] ) . '</label></th><td>';
                        self::select( 'ezpin_settings[' . $key . ']', $s[ $key ], $field[1] );
                        echo '</td></tr>';
                    }
                    foreach ( array( 'min_width' => 'Minimum image width', 'min_height' => 'Minimum image height' ) as $key => $label ) {
                        echo '<tr><th scope="row"><label for="ezpin_settings[' . esc_attr( $key ) . ']">' . esc_html( $label ) . '</label></th><td><input type="number" min="1" max="10000" id="ezpin_settings[' . esc_attr( $key ) . ']" name="ezpin_settings[' . esc_attr( $key ) . ']" value="' . esc_attr( $s[ $key ] ) . '"> px <p class="description">Measured using the full WordPress image dimensions when available, otherwise the loaded intrinsic size.</p></td></tr>';
                    }
                    ?>
                    <tr><th scope="row"><?php esc_html_e( 'Enabled content types', 'ezpin' ); ?></th><td>
                        <?php foreach ( self::post_types() as $type => $object ) : ?>
                            <label style="display:block"><input type="checkbox" name="ezpin_settings[post_types][]" value="<?php echo esc_attr( $type ); ?>" <?php checked( in_array( $type, $s['post_types'], true ) ); ?>> <?php echo esc_html( $object->labels->name ); ?></label>
                        <?php endforeach; ?>
                        <p class="description">Buttons appear on individual entries. Home, search, and archive pages are excluded.</p>
                    </td></tr>
                    <tr><th scope="row"><label for="ezpin_settings[scope]">Image containers</label></th><td><input class="large-text" id="ezpin_settings[scope]" name="ezpin_settings[scope]" value="<?php echo esc_attr( $s['scope'] ); ?>"><p class="description">CSS selectors for content that may contain pinnable images. Separate selectors with commas.</p></td></tr>
                    <tr><th scope="row"><label for="ezpin_settings[excluded]">Excluded CSS selectors</label></th><td><textarea class="large-text" rows="4" id="ezpin_settings[excluded]" name="ezpin_settings[excluded]"><?php echo esc_textarea( $s['excluded'] ); ?></textarea><p class="description">Separate selectors with commas or newlines. Matching images and their descendants are skipped. Logos, avatars, navigation, footers, sidebars, and images marked no-pin are also excluded automatically.</p></td></tr>
                </table>
                <h2><?php esc_html_e( 'Pinterest defaults', 'ezpin' ); ?></h2>
                <p>Individual page and image fields override these defaults. Accessibility alt text stays unchanged.</p>
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><label for="ezpin_settings[title]">Default Pinterest title</label></th><td><input class="large-text" id="ezpin_settings[title]" name="ezpin_settings[title]" value="<?php echo esc_attr( $s['title'] ); ?>"><p class="description">Leave blank to use the Open Graph title or page title. Pinterest may choose its own title in the Save interface.</p></td></tr>
                    <tr><th scope="row"><label for="ezpin_settings[description]">Default Pinterest description</label></th><td><textarea class="large-text" rows="4" id="ezpin_settings[description]" name="ezpin_settings[description]"><?php echo esc_textarea( $s['description'] ); ?></textarea><p class="description">Leave blank to use the page meta description. Alt text is never used as marketing copy.</p></td></tr>
                    <tr><th scope="row"><label for="ezpin_settings[image]">Hidden Pinterest image</label></th><td><?php self::image_field( 'ezpin_settings[image]', $s['image'] ); ?><p class="description">Optional vertical image. A separate Save link appears at the end of the article; the image itself is not displayed or downloaded by EZPin.</p></td></tr>
                    <tr><th scope="row">Force hidden Pinterest image</th><td><label><input type="checkbox" name="ezpin_settings[force_image]" value="1" <?php checked( $s['force_image'] ); ?>> Use the hidden image when saving visible images</label><p class="description">An explicit image-level Pinterest media URL takes priority.</p></td></tr>
                </table>
                <?php submit_button(); ?>
            </form>
            <p>EZPin loads no Pinterest scripts or tracking. Readers sign in and choose a board on Pinterest after clicking Save.</p>
        </div>
        <?php
    }

    public static function meta_boxes() {
        foreach ( array_keys( self::post_types() ) as $type ) {
            add_meta_box( 'ezpin', 'EZPin — Pinterest', array( __CLASS__, 'meta_box' ), $type, 'normal', 'default' );
        }
    }

    public static function meta_box( $post ) {
        wp_nonce_field( 'ezpin_post_' . $post->ID, 'ezpin_nonce' );
        foreach ( array( 'title' => 'Pinterest title', 'description' => 'Pinterest description' ) as $field => $label ) {
            $value = get_post_meta( $post->ID, '_ezpin_' . $field, true );
            echo '<p><label for="ezpin_' . esc_attr( $field ) . '"><strong>' . esc_html( $label ) . '</strong></label><br>';
            if ( 'description' === $field ) {
                echo '<textarea class="widefat" rows="3" id="ezpin_description" name="ezpin_description">' . esc_textarea( $value ) . '</textarea>';
            } else {
                echo '<input class="widefat" id="ezpin_title" name="ezpin_title" value="' . esc_attr( $value ) . '">';
            }
            echo '</p>';
        }
        echo '<p><label for="ezpin_image"><strong>Hidden Pinterest image</strong></label><br>';
        self::image_field( 'ezpin_image', get_post_meta( $post->ID, '_ezpin_image', true ) );
        echo '</p><p><label for="ezpin_force_image">Force hidden image for this page </label>';
        self::select( 'ezpin_force_image', get_post_meta( $post->ID, '_ezpin_force_image', true ), array( '' => 'Use global setting', 'yes' => 'Yes', 'no' => 'No' ) );
        echo '</p><p class="description">Leave fields empty to use site defaults. The hidden image gets its own Save link. The Pin destination remains this page; image-specific Media Library fields take precedence.</p>';
    }

    public static function save_post( $id ) {
        if ( wp_is_post_revision( $id ) || wp_is_post_autosave( $id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $id ) ) {
            return;
        }
        $nonce = isset( $_POST['ezpin_nonce'] ) && is_string( $_POST['ezpin_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['ezpin_nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'ezpin_post_' . $id ) ) {
            return;
        }
        foreach ( array( 'title', 'description', 'image', 'force_image' ) as $field ) {
            $value = isset( $_POST[ 'ezpin_' . $field ] ) && is_string( $_POST[ 'ezpin_' . $field ] ) ? wp_unslash( $_POST[ 'ezpin_' . $field ] ) : '';
            if ( 'image' === $field ) {
                $value = Plugin::http_url( $value );
            } elseif ( 'force_image' === $field ) {
                $value = in_array( $value, array( 'yes', 'no' ), true ) ? $value : '';
            } else {
                $value = self::text( $value, 'description' === $field );
            }
            self::store_meta( $id, $field, $value );
        }
    }

    public static function store_meta( $id, $field, $value ) {
        if ( '' === $value ) {
            delete_post_meta( $id, '_ezpin_' . $field );
        } else {
            update_post_meta( $id, '_ezpin_' . $field, wp_slash( $value ) );
        }
    }

    public static function attachment_fields( $fields, $post ) {
        if ( ! wp_attachment_is_image( $post->ID ) ) {
            return $fields;
        }
        $labels = array( 'title' => 'Pinterest title', 'description' => 'Pinterest description', 'url' => 'Pinterest destination URL', 'media' => 'Pinterest alternate image URL' );
        foreach ( $labels as $key => $label ) {
            $fields[ 'ezpin_' . $key ] = array(
                'label' => $label,
                'input' => 'description' === $key ? 'textarea' : 'text',
                'value' => get_post_meta( $post->ID, '_ezpin_' . $key, true ),
                'helps' => 'url' === $key ? 'Leave blank to link to the current page canonical URL.' : ( 'media' === $key ? 'Optional full https:// URL of a Pinterest-optimized image.' : 'Optional. Overrides page defaults without changing alt text.' ),
            );
        }
        $id = (int) $post->ID;
        $fields['ezpin_nopin'] = array(
            'label' => 'Exclude from Pinterest',
            'input' => 'html',
            'html' => '<input type="hidden" name="attachments[' . $id . '][ezpin_nonce]" value="' . esc_attr( wp_create_nonce( 'ezpin_attachment_' . $id ) ) . '"><input type="hidden" name="attachments[' . $id . '][ezpin_nopin]" value="0"><label><input type="checkbox" name="attachments[' . $id . '][ezpin_nopin]" value="1" ' . checked( get_post_meta( $id, '_ezpin_nopin', true ), '1', false ) . '> Do not show a Save button</label>',
        );
        return $fields;
    }

    public static function save_attachment( $post, $attachment ) {
        $id = (int) $post['ID'];
        $nonce = isset( $attachment['ezpin_nonce'] ) && is_string( $attachment['ezpin_nonce'] ) ? $attachment['ezpin_nonce'] : '';
        if ( ! current_user_can( 'edit_post', $id ) || ! wp_verify_nonce( $nonce, 'ezpin_attachment_' . $id ) ) {
            return $post;
        }
        foreach ( array( 'title', 'description', 'url', 'media', 'nopin' ) as $key ) {
            if ( ! isset( $attachment[ 'ezpin_' . $key ] ) ) {
                continue;
            }
            $value = $attachment[ 'ezpin_' . $key ];
            if ( in_array( $key, array( 'url', 'media' ), true ) ) {
                $value = Plugin::http_url( $value );
            } elseif ( 'nopin' === $key ) {
                $value = '1' === (string) ( is_scalar( $value ) ? $value : '' ) ? '1' : '';
            } else {
                $value = self::text( $value, 'description' === $key );
            }
            self::store_meta( $id, $key, $value );
        }
        return $post;
    }

    public static function enqueue( $hook ) {
        if ( ! in_array( $hook, array( 'settings_page_ezpin', 'post.php', 'post-new.php' ), true ) ) {
            return;
        }
        wp_enqueue_media();
        wp_enqueue_script( 'ezpin-admin', plugins_url( 'assets/admin.js', FILE ), array( 'media-views' ), VERSION, true );
    }
}
