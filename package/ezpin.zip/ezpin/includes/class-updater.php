<?php
/** GitHub release updates through WordPress's native plugin updater. */
namespace EZPin;

defined( 'ABSPATH' ) || exit;

final class Updater {
    const REPOSITORY = 'https://github.com/iamrook/ezpin-releases';
    const MANIFEST = self::REPOSITORY . '/releases/latest/download/ezpin-update.json';
    const CACHE = 'ezpin_github_release_v1';

    public static function boot() {
        add_filter( 'update_plugins_github.com', array( __CLASS__, 'update' ), 10, 4 );
        add_filter( 'plugins_api', array( __CLASS__, 'information' ), 10, 3 );
        add_filter( 'upgrader_pre_download', array( __CLASS__, 'download' ), 10, 4 );
        add_action( 'load-update-core.php', array( __CLASS__, 'force_check' ) );
        add_action( 'upgrader_process_complete', array( __CLASS__, 'after_upgrade' ), 10, 2 );
    }

    /** Accept only stable releases and the exact versioned ZIP in our repository. */
    public static function validate( $data ) {
        if ( ! is_array( $data ) ) {
            return false;
        }
        foreach ( array( 'version', 'download_url', 'sha256', 'requires', 'requires_php', 'tested', 'changelog' ) as $key ) {
            if ( ! isset( $data[ $key ] ) || ! is_string( $data[ $key ] ) ) {
                return false;
            }
        }
        if ( ! preg_match( '/^\d+\.\d+\.\d+$/D', $data['version'] ) ||
            ! preg_match( '/^[a-f0-9]{64}$/D', $data['sha256'] ) ) {
            return false;
        }
        foreach ( array( 'requires', 'requires_php', 'tested' ) as $key ) {
            if ( ! preg_match( '/^\d+\.\d+(?:\.\d+)?$/D', $data[ $key ] ) ) {
                return false;
            }
        }
        $package = self::REPOSITORY . '/releases/download/v' . $data['version'] . '/ezpin-' . $data['version'] . '.zip';
        if ( $package !== $data['download_url'] ) {
            return false;
        }
        return array(
            'version'      => $data['version'],
            'download_url' => $package,
            'sha256'       => $data['sha256'],
            'requires'     => $data['requires'],
            'requires_php' => $data['requires_php'],
            'tested'       => $data['tested'],
            'changelog'    => $data['changelog'],
        );
    }

    public static function release() {
        $cached = get_site_transient( self::CACHE );
        if ( false !== $cached ) {
            return self::validate( $cached );
        }
        $response = wp_safe_remote_get( self::MANIFEST, array(
            'timeout'             => 8,
            'redirection'         => 5,
            'limit_response_size' => 65536,
            'user-agent'          => 'EZPin-Updater/' . VERSION,
            'headers'             => array( 'Accept' => 'application/json' ),
        ) );
        $release = false;
        if ( ! is_wp_error( $response ) && 200 === wp_remote_retrieve_response_code( $response ) ) {
            $release = self::validate( json_decode( wp_remote_retrieve_body( $response ), true ) );
        }
        // Cache failures briefly too, avoiding repeated requests when GitHub is unavailable.
        set_site_transient( self::CACHE, $release ? $release : array(), $release ? 6 * HOUR_IN_SECONDS : 15 * MINUTE_IN_SECONDS );
        return $release;
    }

    public static function update( $update, $plugin_data, $plugin_file, $locales ) {
        if ( plugin_basename( FILE ) !== $plugin_file ) {
            return $update;
        }
        $release = self::release();
        if ( ! $release ) {
            return $update;
        }
        // Return equal versions as well: core records no_update and offers its auto-update toggle.
        // Do not set autoupdate: installation remains the site administrator's choice.
        return array(
            'id'           => self::REPOSITORY,
            'slug'         => 'ezpin',
            'version'      => $release['version'],
            'url'          => self::REPOSITORY . '/releases/tag/v' . $release['version'],
            'package'      => $release['download_url'],
            'requires'     => $release['requires'],
            'requires_php' => $release['requires_php'],
            'tested'       => $release['tested'],
        );
    }

    public static function information( $result, $action, $args ) {
        if ( 'plugin_information' !== $action || ! isset( $args->slug ) || 'ezpin' !== $args->slug ) {
            return $result;
        }
        $release = self::release();
        return (object) array(
            'name'          => 'EZPin',
            'slug'          => 'ezpin',
            'version'       => $release ? $release['version'] : VERSION,
            'author'        => '<a href="https://odditymall.com/">OddityMall</a>',
            'homepage'      => self::REPOSITORY,
            'requires'      => $release ? $release['requires'] : '6.2',
            'requires_php'  => $release ? $release['requires_php'] : '7.4',
            'tested'        => $release ? $release['tested'] : '',
            'download_link' => $release ? $release['download_url'] : '',
            'sections'      => array(
                'description' => '<p>' . esc_html__( 'Pinterest image Save buttons with per-page and per-image controls. Updates are distributed by OddityMall through GitHub.', 'ezpin' ) . '</p>',
                'changelog'   => '<pre>' . esc_html( $release ? $release['changelog'] : __( 'Release information is temporarily unavailable. Check again later.', 'ezpin' ) ) . '</pre>',
            ),
        );
    }

    /** Verify the release ZIP before WordPress extracts or installs it. */
    public static function download( $reply, $package, $upgrader, $hook_extra ) {
        if ( false !== $reply ) {
            return $reply;
        }
        $is_ours = isset( $hook_extra['plugin'] ) && plugin_basename( FILE ) === $hook_extra['plugin'];
        $is_release = is_string( $package ) && 0 === strpos( $package, self::REPOSITORY . '/releases/download/' );
        if ( ! $is_ours && ! $is_release ) {
            return $reply;
        }
        $release = self::release();
        if ( ! $release || $release['download_url'] !== $package ) {
            return new \WP_Error( 'ezpin_release_unavailable', __( 'EZPin could not verify this release. Go to Dashboard > Updates, click Check again, and retry.', 'ezpin' ) );
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $file = download_url( $package );
        if ( is_wp_error( $file ) ) {
            return $file;
        }
        $actual = hash_file( 'sha256', $file );
        if ( ! is_string( $actual ) || ! hash_equals( $release['sha256'], $actual ) ) {
            wp_delete_file( $file );
            return new \WP_Error( 'ezpin_checksum_mismatch', __( 'The EZPin download failed its integrity check. Nothing was installed. Please retry later.', 'ezpin' ) );
        }
        return $file;
    }

    public static function force_check() {
        if ( current_user_can( 'update_plugins' ) && ! empty( $_GET['force-check'] ) ) {
            delete_site_transient( self::CACHE );
        }
    }

    public static function after_upgrade( $upgrader, $options ) {
        $plugins = isset( $options['plugins'] ) ? (array) $options['plugins'] : array();
        if ( isset( $options['plugin'] ) ) {
            $plugins[] = $options['plugin'];
        }
        if ( in_array( plugin_basename( FILE ), $plugins, true ) ) {
            delete_site_transient( self::CACHE );
        }
    }
}
