<?php
namespace EZPin;

defined( 'ABSPATH' ) || exit;

final class Plugin {
    public static function boot() {
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
        add_filter( 'wp_get_attachment_image_attributes', array( __CLASS__, 'image_attributes' ), 20, 2 );
        add_filter( 'the_content', array( __CLASS__, 'content_images' ), 20 );
        add_filter( 'plugin_action_links_' . plugin_basename( FILE ), array( __CLASS__, 'settings_link' ) );
    }

    public static function defaults() {
        return array(
            'enabled' => true,
            'button_text' => 'Save',
            'position' => 'top-left',
            'desktop' => 'hover',
            'mobile' => 'visible',
            'min_width' => 300,
            'min_height' => 300,
            'scope' => 'main, article, .entry-content, .woocommerce-product-gallery',
            'excluded' => '.logo, .avatar, .site-header, .site-footer, .no-pinterest, .no-pin, .yarpp-related, .yarpp-thumbnails-horizontal, .related, .related-posts, .author-box, .om-author-note, .om-related, .om-sidebar, .om-recent-posts',
            'post_types' => array( 'post', 'page', 'product' ),
            'title' => '',
            'description' => '',
            'image' => '',
            'force_image' => false,
        );
    }

    public static function settings() {
        $saved = get_option( 'ezpin_settings', array() );
        return wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
    }

    public static function http_url( $value ) {
        if ( ! is_string( $value ) || ! preg_match( '~^https?://~i', trim( $value ) ) ) {
            return '';
        }
        return esc_url_raw( trim( $value ), array( 'http', 'https' ) );
    }

    public static function allowed() {
        $settings = self::settings();
        return ! is_admin() && ! is_feed() && ! is_embed() && ! post_password_required()
            && $settings['enabled'] && ! empty( $settings['post_types'] ) && is_singular( $settings['post_types'] );
    }

    public static function page_data() {
        $settings = self::settings();
        $id = get_queried_object_id();
        $force = get_post_meta( $id, '_ezpin_force_image', true );
        return array(
            'title' => get_post_meta( $id, '_ezpin_title', true ) ?: $settings['title'],
            'description' => get_post_meta( $id, '_ezpin_description', true ) ?: $settings['description'],
            'image' => self::http_url( get_post_meta( $id, '_ezpin_image', true ) ) ?: $settings['image'],
            'forceImage' => 'yes' === $force || ( 'no' !== $force && $settings['force_image'] ),
        );
    }

    public static function enqueue() {
        if ( ! self::allowed() ) {
            return;
        }
        $settings = self::settings();
        $config = array(
            'buttonText' => $settings['button_text'],
            'position' => $settings['position'],
            'desktop' => $settings['desktop'],
            'mobile' => $settings['mobile'],
            'minWidth' => (int) $settings['min_width'],
            'minHeight' => (int) $settings['min_height'],
            'scope' => $settings['scope'],
            'excluded' => $settings['excluded'],
            'page' => self::page_data(),
            'label' => __( 'Save image to Pinterest (opens in a new window)', 'ezpin' ),
            'hiddenLabel' => __( 'Save the Pinterest image', 'ezpin' ),
        );
        wp_enqueue_style( 'ezpin', plugins_url( 'assets/ezpin.css', FILE ), array(), VERSION );
        wp_enqueue_script( 'ezpin', plugins_url( 'assets/ezpin.js', FILE ), array(), VERSION, true );
        // Escaping tag delimiters prevents stored text from closing the inline script.
        wp_add_inline_script( 'ezpin', 'window.EZPinConfig = ' . wp_json_encode( $config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . ';', 'before' );
    }

    public static function attachment_data( $id ) {
        $attributes = array();
        foreach ( array( 'title', 'description', 'url', 'media' ) as $field ) {
            $value = get_post_meta( $id, '_ezpin_' . $field, true );
            if ( is_string( $value ) && '' !== $value ) {
                $attributes[ 'data-pin-' . $field ] = in_array( $field, array( 'url', 'media' ), true ) ? self::http_url( $value ) : $value;
            }
        }
        if ( get_post_meta( $id, '_ezpin_nopin', true ) ) {
            $attributes['data-pin-nopin'] = 'true';
        }
        $full = wp_get_attachment_image_src( $id, 'full' );
        if ( $full ) {
            $attributes['data-ezpin-full'] = $full[0];
            $attributes['data-ezpin-width'] = (string) $full[1];
            $attributes['data-ezpin-height'] = (string) $full[2];
        }
        return $attributes;
    }

    public static function image_attributes( $attributes, $attachment ) {
        if ( ! self::allowed() ) {
            return $attributes;
        }
        // Explicit markup attributes take precedence over the Media Library defaults.
        return array_merge( self::attachment_data( $attachment->ID ), $attributes );
    }

    public static function content_images( $content ) {
        if ( ! self::allowed() || ! is_main_query() || ! in_the_loop() ) {
            return $content;
        }
        $html = new \WP_HTML_Tag_Processor( $content );
        while ( $html->next_tag( 'IMG' ) ) {
            $class = (string) $html->get_attribute( 'class' );
            if ( ! preg_match( '/(?:^|\s)wp-image-(\d+)(?:\s|$)/', $class, $match ) ) {
                continue;
            }
            foreach ( self::attachment_data( (int) $match[1] ) as $key => $value ) {
                if ( null === $html->get_attribute( $key ) ) {
                    $html->set_attribute( $key, $value );
                }
            }
        }
        return $html->get_updated_html();
    }

    public static function settings_link( $links ) {
        array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=ezpin' ) ) . '">' . esc_html__( 'Settings', 'ezpin' ) . '</a>' );
        return $links;
    }
}
