<?php
/**
 * Plugin Name: EZPin
 * Plugin URI: https://github.com/iamrook/ezpin-releases
 * Description: Accessible Pinterest Save buttons with separate image, destination, and Pinterest metadata controls.
 * Version: 1.1.0
 * Update URI: https://github.com/iamrook/ezpin-releases
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Author: OddityMall
 * Author URI: https://odditymall.com/
 * License: GPL-2.0-or-later
 * Text Domain: ezpin
 */

namespace EZPin;

defined( 'ABSPATH' ) || exit;

const VERSION = '1.1.0';
const FILE = __FILE__;

require_once __DIR__ . '/includes/class-plugin.php';
require_once __DIR__ . '/includes/class-admin.php';
require_once __DIR__ . '/includes/class-updater.php';

Plugin::boot();
Updater::boot();
if ( is_admin() ) {
    Admin::boot();
}
